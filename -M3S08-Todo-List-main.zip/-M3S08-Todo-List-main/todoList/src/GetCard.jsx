

export function GetCard( ){
    
    
    return(
        <div>
            <h1>teste get</h1>
        </div>
    )
}